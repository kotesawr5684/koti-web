(function ($) {
	"use strict";

	/*--------------------------
	preloader
	---------------------------- */

	$(window).on('load', function () {
		var pre_loader = $('#preloader')
		pre_loader.fadeOut('slow', function () { $(this).remove(); });
	});


	/*------------------------------------
	 search option
	------------------------------------- */

	$('.search-option').hide();
	$(".main-search").on('click', function () {
		$('.search-option').animate({
			height: 'toggle',
		});
	});

	/*---------------------
	 TOP Menu Stick
	--------------------- */

	var windows = $(window);
	var sticky = $('#sticker');

	windows.on('scroll', function () {
		var scroll = windows.scrollTop();
		if (scroll < 300) {
			sticky.removeClass('stick');
		} else {
			sticky.addClass('stick');
		}
	});

	/*----------------------------
	 jQuery MeanMenu
	------------------------------ */

	var mean_menu = $('nav#dropdown');
	mean_menu.meanmenu();

	/*---------------------
	 wow .js
	--------------------- */
	function wowAnimation() {
		new WOW({
			offset: 100,
			mobile: true
		}).init()
	}
	wowAnimation()

	/*--------------------------
	 scrollUp
	---------------------------- */

	$.scrollUp({
		scrollText: '<i class="icon icon-arrow-up"></i>',
		easingType: 'linear',
		scrollSpeed: 900,
		animation: 'fade'
	});

	/*----------------------------
	 Counter js active
	------------------------------ */

	var count = $('.counter');
	count.counterUp({
		delay: 40,
		time: 3000
	});

	/*--------------------------
	 collapse
	---------------------------- */

	var panel_test = $('.panel-heading a');
	panel_test.on('click', function () {
		panel_test.removeClass('active');
		$(this).addClass('active');
	});

	/*--------------------------
	 MagnificPopup
	---------------------------- */

	$('.video-play').magnificPopup({
		type: 'iframe'
	});
	/*--------------------------
	 Parallax
	---------------------------- */
	var parallaxeffect = $(window);
	parallaxeffect.stellar({
		responsive: true,
		positionProperty: 'position',
		horizontalScrolling: false
	});

	/*---------------------
	 Testimonial carousel
	---------------------*/

	var review = $('.testimonial-carousel');
	review.owlCarousel({
		loop: true,
		nav: false,
		margin: 30,
		center: true,
		dots: true,
		autoplay: false,
		responsive: {
			0: {
				items: 1
			},
			768: {
				items: 2
			},
			1000: {
				items: 2
			}
		}
	});

	/*----------------------------
		Contact form
	------------------------------ */
	$("#contactForm").on("submit", function (event) {
		if (event.isDefaultPrevented()) {
			formError();
			submitMSG(false, "Did you fill in the form properly?");
		} else {
			event.preventDefault();
			submitForm();
		}
	});
	function submitForm() {
		var name = $("#name").val();
		var email = $("#email").val();
		var msg_subject = $("#msg_subject").val();
		var message = $("#message").val();


		$.ajax({
			type: "POST",
			url: "assets/contact.php",
			data: "name=" + name + "&email=" + email + "&msg_subject=" + msg_subject + "&message=" + message,
			success: function (text) {
				if (text === "success") {
					formSuccess();
				} else {
					formError();
					submitMSG(false, text);
				}
			}
		});
	}

	function formSuccess() {
		$("#contactForm")[0].reset();
		submitMSG(true, "Message Submitted!")
	}

	function formError() {
		$("#contactForm").removeClass().addClass('shake animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
			$(this).removeClass();
		});
	}

	function submitMSG(valid, msg) {
		if (valid) {
			var msgClasses = "h3 text-center tada animated text-success";
		} else {
			var msgClasses = "h3 text-center text-danger";
		}
		$("#msgSubmit").removeClass().addClass(msgClasses).text(msg);
	}



})(jQuery);

// you tube video 
var player = null;
var tag = document.createElement("script");
tag.id = "iframe-api";
tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName("script")[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

function onYouTubeIframeAPIReady() {
	player = new YT.Player("existing-iframe-example");
}

var elPopupClose = $(".popup__close");
var elPopupOverlay = $(".popup__overlay");
var elPopupToggle = $("#popup__toggle");

// @see https://developers.google.com/youtube/iframe_api_reference#Playback_controls
// @see http://stackoverflow.com/questions/8667882/how-to-pause-a-youtube-player-when-hiding-the-iframe
function popupDidClose() {
	if (player !== null) {
		player.pauseVideo();
	}
}

elPopupClose.click(function () {
	elPopupOverlay.css({ display: "none", visibility: "hidden", opacity: 0 });
	popupDidClose();
});

elPopupOverlay.click(function (event) {
	event = event || window.event;
	if (event.target === this) {
		elPopupOverlay.css({ display: "none", visibility: "hidden", opacity: 0 });
		popupDidClose();
	}
});

elPopupToggle.click(function () {
	elPopupOverlay.css({ display: "block", visibility: "visible", opacity: 1 });
});


// this is only contient slider

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
	showSlides(slideIndex += n);
}

function currentSlide(n) {
	showSlides(slideIndex = n);
}

function showSlides(n) {
	var i;
	var slides = document.getElementsByClassName("mySlides");
	var dots = document.getElementsByClassName("dot_ball");
	if (n > slides.length) { slideIndex = 1 }
	if (n < 1) { slideIndex = slides.length }
	for (i = 0; i < slides.length; i++) {
		slides[i].style.display = "none";
	}
	for (i = 0; i < dots.length; i++) {
		dots[i].className = dots[i].className.replace(" active", "");
	}
	slides[slideIndex - 1].style.display = "block" ;
	dots[slideIndex - 1].className += " active";
}

// This is about section backgroud moving




